# React Calculator App

A clean, modern calculator built with React and Tailwind CSS.

## Features

- ✅ Basic arithmetic operations (+, −, ×, ÷)
- ✅ Responsive design
- ✅ Keyboard support
- ✅ Error handling (divide by zero)
- ✅ Beautiful gradient buttons
- ✅ Smooth animations

## Installation

```bash
npm install
npm start
```

Open http://localhost:3000
